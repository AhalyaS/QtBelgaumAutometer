#include "stackedwidgets.h"
#include <QDebug>

StackedWidgets::StackedWidgets(QWidget *parent) :
    QWidget(parent)
{
    QStackedLayout *st = new QStackedLayout();
    setLayout(st);

    md = new MapDisplay();
    sp = new StartPage();

    flag = 0;

/*
    #if defined(Q_OS_SYMBIAN) || defined(Q_OS_WINCE_WM) || defined(Q_WS_MAEMO_5) || defined(Q_WS_MAEMO_6)
        mw->showMaximized();
    #else
        mw->show();
    #endif
*/
    layout()->addWidget(md);
    layout()->addWidget(sp);

    change_time = new QTimer(this);
    change_time->setInterval(2000);
    change_time->start();

    connect(change_time, SIGNAL(timeout()), this, SLOT(changeWidget()));
}

void StackedWidgets::changeWidget()
{
    QStackedLayout *lay = qobject_cast<QStackedLayout*>(layout());

    qDebug()<<"changeWidget()";

    if(flag == 0)
    {
        lay->setCurrentWidget(md);

        qDebug()<<"if";
        flag = 1;
    }
    else
    {
        lay->setCurrentWidget(sp);

        qDebug()<<"Else";
        flag = 0;
    }
}
